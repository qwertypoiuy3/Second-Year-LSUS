/**
 * File: Calculable.java
 * Author: KARIN HERNANDEZ
 * Concentration: Software Development
 * Date: 09/09/2020
 * Class description: Lab 03
 */
public interface Calculable 
{
    public double getPerimeter();
    public double getArea(); 
}
